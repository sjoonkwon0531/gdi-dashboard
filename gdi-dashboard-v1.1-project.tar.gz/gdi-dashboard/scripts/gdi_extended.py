#!/usr/bin/env python3
"""
GDI Extended Engine — Additional computations for:
1. GDI vs GDP correlation
2. GDP as f(GDI) post-2016
3. Feedback cycle modeling
4. Disruption scenarios
5. Sovereign AI impact
"""
import json, math, os
import numpy as np
np.random.seed(42)

# Load base data
base_dir = os.path.dirname(__file__)
with open(os.path.join(base_dir, "..", "src", "data", "gdi_data.json")) as f:
    DATA = json.load(f)

# ═══════════════════════════════════════
# 1. GDI vs GDP CORRELATION
# ═══════════════════════════════════════
def compute_gdp_gdi_correlation():
    """Compute GDI vs GDP relationship across countries and time."""
    results = {"cross_section_2025": [], "time_series": {}, "regression": {}}

    # Cross-section: 2025 snapshot
    for code, c in DATA["countries"].items():
        s = c["snapshot_2025"]
        results["cross_section_2025"].append({
            "code": code, "name": c["name"],
            "gdp": s["gdp"], "gdi_flex": s["gdi_flex"], "gdi_strict": s["gdi_strict"],
            "gdp_pc": round(s["gdp"] / c["population"] * 1000, 1),  # GDP per capita ($K)
            "gdi_pc": round(s["gdi_flex_per_capita"], 3),
            "pop": c["population"],
        })

    # Time series for key countries: GDI and GDP co-movement
    for code in ["USA", "CHN", "KOR", "DEU", "IND", "JPN", "GBR", "FRA"]:
        c = DATA["countries"][code]
        ts = []
        for h in c["historical"]:
            ts.append({"year": h["year"], "gdi": h["gdi_flex"], "gdp": h["gdp"]})
        # Add forecast median
        for f in c["forecast"]:
            gdi_med = f.get("gdi_flex_p50_0", 0)
            # Estimate GDP from forecast (simple growth)
            base_gdp = c["snapshot_2025"]["gdp"]
            years_out = f["year"] - 2025
            est_gdp = base_gdp * (1.02 ** years_out)  # ~2% baseline growth
            ts.append({"year": f["year"], "gdi": round(gdi_med, 2), "gdp": round(est_gdp, 1), "forecast": True})
        results["time_series"][code] = ts

    # Regression: log(GDP) = a + b * log(GDI) for 2025 cross-section
    gdis = [x["gdi_flex"] for x in results["cross_section_2025"] if x["gdi_flex"] > 0.5]
    gdps = [x["gdp"] for x in results["cross_section_2025"] if x["gdi_flex"] > 0.5]
    log_gdi = np.log(gdis)
    log_gdp = np.log(gdps)
    # Simple OLS
    n = len(log_gdi)
    mean_x, mean_y = np.mean(log_gdi), np.mean(log_gdp)
    ss_xy = np.sum((log_gdi - mean_x) * (log_gdp - mean_y))
    ss_xx = np.sum((log_gdi - mean_x) ** 2)
    b = ss_xy / ss_xx
    a = mean_y - b * mean_x
    # R-squared
    y_hat = a + b * log_gdi
    ss_res = np.sum((log_gdp - y_hat) ** 2)
    ss_tot = np.sum((log_gdp - mean_y) ** 2)
    r2 = 1 - ss_res / ss_tot
    results["regression"] = {
        "intercept": round(a, 4), "slope": round(b, 4),
        "r_squared": round(r2, 4), "pearson_r": round(math.sqrt(r2), 4),
        "interpretation": f"log(GDP) = {a:.2f} + {b:.2f} * log(GDI), R² = {r2:.3f}"
    }

    return results

# ═══════════════════════════════════════
# 2. GDP AS FUNCTION OF GDI (post-2016)
# ═══════════════════════════════════════
def compute_gdp_elasticity():
    """Estimate GDP elasticity to GDI changes in the AI era (2016+)."""
    results = {"elasticities": {}, "ai_gdp_contribution": {}}

    for code in ["USA", "CHN", "KOR", "DEU", "IND", "JPN", "GBR", "FRA"]:
        c = DATA["countries"][code]
        hist = c["historical"]
        # Get 2016+ data points
        ai_era = [h for h in hist if h["year"] >= 2016]
        if len(ai_era) < 3:
            continue

        # Compute year-over-year growth rates
        gdi_changes = []
        gdp_changes = []
        for i in range(1, len(ai_era)):
            dg = (ai_era[i]["gdi_flex"] - ai_era[i-1]["gdi_flex"]) / max(ai_era[i-1]["gdi_flex"], 0.01)
            dy = (ai_era[i]["gdp"] - ai_era[i-1]["gdp"]) / max(ai_era[i-1]["gdp"], 1)
            gdi_changes.append(dg)
            gdp_changes.append(dy)

        # Elasticity: %ΔGDP / %ΔGDI
        if len(gdi_changes) > 0:
            avg_gdi_g = np.mean(gdi_changes)
            avg_gdp_g = np.mean(gdp_changes)
            elasticity = avg_gdp_g / max(avg_gdi_g, 0.001)
            results["elasticities"][code] = {
                "elasticity": round(elasticity, 4),
                "avg_gdi_growth": round(avg_gdi_g * 100, 2),
                "avg_gdp_growth": round(avg_gdp_g * 100, 2),
            }

    # AI contribution to GDP (estimated)
    # Based on McKinsey/PwC estimates: AI adds 1-6% to GDP by 2030
    for code in ["USA", "CHN", "KOR", "DEU", "IND", "JPN", "GBR", "FRA"]:
        c = DATA["countries"][code]
        gdp_2025 = c["snapshot_2025"]["gdp"]
        gdi_2025 = c["snapshot_2025"]["gdi_flex"]
        eta = c["snapshot_2025"]["eta"]

        # AI GDP contribution = GDI * eta * scaling factor
        ai_contrib_pct = gdi_2025 * eta * 0.08  # calibrated to ~3-5% for US
        results["ai_gdp_contribution"][code] = {
            "gdp_2025": gdp_2025,
            "ai_contrib_pct": round(ai_contrib_pct, 2),
            "ai_contrib_bn": round(gdp_2025 * ai_contrib_pct / 100, 1),
            "projected_2030": round(ai_contrib_pct * 1.8, 2),  # ~1.8x growth
            "projected_2036": round(ai_contrib_pct * 3.2, 2),
        }

    return results

# ═══════════════════════════════════════
# 3. FEEDBACK CYCLE: GDI→GDP→M→GDI
# ═══════════════════════════════════════
def compute_feedback_cycle():
    """Model the GDI→GDP→Money→GDI reinforcement cycle."""
    results = {"cycles": {}, "multiplier_analysis": {}}

    for code in ["USA", "CHN", "KOR", "DEU", "IND"]:
        c = DATA["countries"][code]
        s = c["snapshot_2025"]

        # Cycle parameters
        gdi = s["gdi_flex"]
        gdp = s["gdp"]
        eta = s["eta"]
        invest_rate = s.get("compute_invest_share", 0.03) + s.get("energy_invest_share", 0.02)

        # Simulate 10-year feedback cycle
        cycle = []
        g, m = gdi, gdp
        for t in range(11):
            ai_value = g * eta * 0.08 * m / 100  # AI-generated economic value ($B)
            reinvestment = ai_value * invest_rate * 10  # Reinvestment into C+E
            gdi_boost = reinvestment * 0.002  # Investment → GDI conversion

            cycle.append({
                "year": 2025 + t,
                "gdi": round(g, 2),
                "gdp": round(m, 1),
                "ai_value": round(ai_value, 1),
                "reinvestment": round(reinvestment, 1),
                "gdi_boost": round(gdi_boost, 3),
            })

            # Next period
            m = m * 1.022 + ai_value * 0.5  # GDP grows + AI boost
            g = g * 0.95 + gdi_boost + g * eta * 0.02  # Depreciation + reinvestment + efficiency

        results["cycles"][code] = cycle

        # Multiplier: how much $1 invested in GDI returns via the cycle
        total_invested = sum(c["reinvestment"] for c in cycle)
        total_ai_value = sum(c["ai_value"] for c in cycle)
        if total_invested > 0:
            results["multiplier_analysis"][code] = {
                "cycle_multiplier": round(total_ai_value / max(total_invested, 1), 2),
                "10yr_ai_value_total": round(total_ai_value, 1),
                "10yr_reinvestment_total": round(total_invested, 1),
            }

    return results

# ═══════════════════════════════════════
# 4. DISRUPTION SCENARIOS
# ═══════════════════════════════════════
def compute_disruption_scenarios():
    """Model technology disruption impacts on GDI trajectories."""
    scenarios = {
        "superconductor": {
            "name": "Room-Temperature Superconductor",
            "description": "Practical RT superconductor commercialized",
            "year": 2031,
            "effects": {
                "e_td_multiplier": 2.5,      # T&D losses → near zero
                "lcoe_reduction": 0.40,       # 40% LCOE reduction (no resistive loss)
                "compute_efficiency": 1.8,    # 80% more efficient chips
                "storage_boost": 1.5,         # SMES becomes viable
            },
            "probability": 0.05,
            "development_time": 5,  # years to scale
        },
        "fusion": {
            "name": "Commercial Nuclear Fusion",
            "description": "Net-positive fusion power plant operational at scale",
            "year": 2035,
            "effects": {
                "e_gen_boost": 50,            # +50 points to generation
                "lcoe_new": 0.015,            # $0.015/kWh (near-zero marginal cost)
                "coal_replacement": 1.0,      # Replaces all coal
                "gas_replacement": 0.7,       # Replaces 70% gas
            },
            "probability": 0.08,
            "development_time": 8,
        },
        "novel_semiconductor": {
            "name": "Post-Silicon Semiconductor Breakthrough",
            "description": "Carbon nanotube / photonic / neuromorphic chips at scale",
            "year": 2029,
            "effects": {
                "compute_multiplier": 5.0,    # 5x compute per watt
                "learning_rate_boost": 0.10,  # +10% to chip learning rate
                "energy_per_flop": 0.2,       # 80% energy reduction per FLOP
                "china_leapfrog": True,        # Potentially bypasses US chip controls
            },
            "probability": 0.15,
            "development_time": 4,
        },
        "space_datacenter": {
            "name": "Orbital Data Centers",
            "description": "Large-scale computing in orbit with space solar power",
            "year": 2038,
            "effects": {
                "compute_add": 30,            # +30 points compute for space-capable nations
                "energy_unlimited": True,     # Solar in space = near-unlimited
                "latency_penalty": 0.85,      # 15% penalty for latency
                "access_nations": ["USA", "CHN", "ARE", "IND", "JPN"],
            },
            "probability": 0.03,
            "development_time": 10,
        },
    }

    # Simulate each scenario's impact on top countries
    impact_results = {}
    for sc_key, sc in scenarios.items():
        impacts = {}
        for code in ["USA", "CHN", "KOR", "DEU", "IND", "JPN", "GBR", "FRA", "ARE", "TWN"]:
            c = DATA["countries"][code]
            s = c["snapshot_2025"]
            base_gdi = s["gdi_flex"]

            # Calculate modified GDI under scenario
            new_C = s["C"]
            new_E = s["E"]
            new_eta = s["eta"]

            if sc_key == "superconductor":
                new_E *= sc["effects"]["e_td_multiplier"] * 0.3 + 0.7  # Partial T&D improvement
                new_C *= sc["effects"]["compute_efficiency"]
                new_E = min(new_E, 100)
                new_C = min(new_C, 150)

            elif sc_key == "fusion":
                new_E += sc["effects"]["e_gen_boost"] * 0.5  # Gradual adoption
                new_E = min(new_E, 100)

            elif sc_key == "novel_semiconductor":
                new_C *= sc["effects"]["compute_multiplier"] * 0.4 + 0.6  # Partial adoption
                if sc["effects"].get("china_leapfrog") and code == "CHN":
                    new_C *= 1.5  # China leapfrogs chip controls
                new_C = min(new_C, 150)

            elif sc_key == "space_datacenter":
                if code in sc["effects"]["access_nations"]:
                    new_C += sc["effects"]["compute_add"]
                    new_C *= sc["effects"]["latency_penalty"]

            # Recompute GDI
            alpha, sigma = 0.55, 0.2
            rho = (sigma - 1) / sigma
            F = (alpha * max(new_C, 0.01)**rho + (1-alpha) * max(new_E, 0.01)**rho) ** (1/rho)
            gdp_f = math.log(max(s["gdp"], 1)) / math.log(30000)
            new_gdi = F * new_eta * gdp_f

            change_pct = (new_gdi - base_gdi) / max(base_gdi, 0.01) * 100

            impacts[code] = {
                "base_gdi": round(base_gdi, 2),
                "new_gdi": round(new_gdi, 2),
                "change_pct": round(change_pct, 1),
                "new_C": round(new_C, 1),
                "new_E": round(new_E, 1),
            }

        impact_results[sc_key] = {
            "info": {k: v for k, v in sc.items() if k != "effects"},
            "impacts": impacts,
        }

    return {"scenarios": scenarios, "impacts": impact_results}

# ═══════════════════════════════════════
# 5. SOVEREIGN AI IMPACT
# ═══════════════════════════════════════
def compute_sovereign_ai():
    """Model the impact of sovereign AI (domestically developed/controlled AI) on GDI."""
    results = {"profiles": {}, "scenarios": {}}

    # Sovereign AI score (0-100): degree of domestic AI model development & control
    sovereign_scores = {
        "USA": 95,  # OpenAI, Google, Anthropic, Meta — dominant
        "CHN": 85,  # Baidu, Alibaba, DeepSeek — strong domestic
        "GBR": 45,  # DeepMind (Google), limited sovereign models
        "FRA": 55,  # Mistral AI — growing sovereign capability
        "KOR": 35,  # Samsung AI, limited frontier models
        "JPN": 30,  # Sakana AI, limited but growing
        "DEU": 20,  # Aleph Alpha (struggling), mostly US dependent
        "IND": 25,  # Krutrim, early stage
        "ARE": 40,  # G42, Falcon — active sovereign AI push
        "TWN": 15,  # Hardware leader but model-dependent
        "ISR": 55,  # AI21, strong talent but small scale
        "CAN": 40,  # Cohere, academic strength
        "SAU": 30,  # SDAIA initiative
        "SGP": 25,  # Government AI push, limited models
    }

    for code, sov_score in sovereign_scores.items():
        if code not in DATA["countries"]:
            continue
        c = DATA["countries"][code]
        s = c["snapshot_2025"]

        # Sovereign AI affects eta (efficiency) and C_model
        # Higher sovereignty = better eta (domestic value capture) + model resilience
        base_eta = s["eta"]
        base_c_model = s.get("c_model", 50)

        # Sovereignty premium on eta: countries that develop their own AI
        # capture more economic value domestically
        sovereignty_eta_boost = sov_score / 100 * 0.15  # up to +0.15 eta
        # Sovereignty risk: dependency on foreign AI creates vulnerability
        dependency_risk = (100 - sov_score) / 100 * 0.20  # up to -0.20 eta in crisis

        results["profiles"][code] = {
            "name": c["name"],
            "sovereign_score": sov_score,
            "base_gdi": s["gdi_flex"],
            "base_eta": base_eta,
            "boosted_eta": round(min(base_eta + sovereignty_eta_boost, 0.98), 3),
            "crisis_eta": round(max(base_eta - dependency_risk, 0.1), 3),
            "eta_range": round(sovereignty_eta_boost + dependency_risk, 3),
        }

    # Scenario: What if sovereignty changes?
    # Three scenarios per country
    for code in sovereign_scores:
        if code not in DATA["countries"]:
            continue
        s = DATA["countries"][code]["snapshot_2025"]
        base_gdi = s["gdi_flex"]

        scenarios = {}
        for sov_level, sov_name in [(100, "Full Sovereignty"), (50, "Partial"), (10, "Dependent")]:
            # Recalculate with different sovereignty
            eta_adj = s["eta"] + (sov_level - sovereign_scores[code]) / 100 * 0.15
            eta_adj = max(0.1, min(0.98, eta_adj))

            alpha, sigma = 0.55, 0.2
            rho = (sigma - 1) / sigma
            C, E = s["C"], s["E"]
            F = (alpha * max(C, 0.01)**rho + (1-alpha) * max(E, 0.01)**rho) ** (1/rho)
            gdp_f = math.log(max(s["gdp"], 1)) / math.log(30000)
            new_gdi = F * eta_adj * gdp_f

            scenarios[sov_name] = {
                "sovereignty": sov_level,
                "eta": round(eta_adj, 3),
                "gdi": round(new_gdi, 2),
                "change_pct": round((new_gdi - base_gdi) / max(base_gdi, 0.01) * 100, 1),
            }

        results["scenarios"][code] = scenarios

    return results


# ═══════════════════════════════════════
# MAIN
# ═══════════════════════════════════════
def main():
    print("Computing extended GDI analyses...")

    ext = {
        "gdp_gdi_correlation": compute_gdp_gdi_correlation(),
        "gdp_elasticity": compute_gdp_elasticity(),
        "feedback_cycle": compute_feedback_cycle(),
        "disruption_scenarios": compute_disruption_scenarios(),
        "sovereign_ai": compute_sovereign_ai(),
    }

    out_path = os.path.join(base_dir, "..", "src", "data", "gdi_extended.json")
    with open(out_path, "w") as f:
        json.dump(ext, f, separators=(",", ":"))

    print(f"Extended data: {os.path.getsize(out_path)/1024:.0f} KB")

    # Print key findings
    reg = ext["gdp_gdi_correlation"]["regression"]
    print(f"\nGDP-GDI Regression: {reg['interpretation']}")
    print(f"Pearson r = {reg['pearson_r']}")

    print("\nAI GDP Contribution (2025):")
    for code, v in ext["gdp_elasticity"]["ai_gdp_contribution"].items():
        print(f"  {code}: {v['ai_contrib_pct']:.1f}% (${v['ai_contrib_bn']:.0f}B)")

    print("\nFeedback Cycle Multipliers:")
    for code, v in ext["feedback_cycle"]["multiplier_analysis"].items():
        print(f"  {code}: {v['cycle_multiplier']:.2f}x")

    print("\nDisruption Scenario Impacts (USA):")
    for sc, v in ext["disruption_scenarios"]["impacts"].items():
        usa = v["impacts"].get("USA", {})
        print(f"  {sc}: {usa.get('base_gdi',0):.1f} → {usa.get('new_gdi',0):.1f} ({usa.get('change_pct',0):+.1f}%)")

    print("\nSovereign AI Scores:")
    for code, v in ext["sovereign_ai"]["profiles"].items():
        print(f"  {code}: score={v['sovereign_score']}, eta range=[{v['crisis_eta']:.2f}, {v['boosted_eta']:.2f}]")


if __name__ == "__main__":
    main()
