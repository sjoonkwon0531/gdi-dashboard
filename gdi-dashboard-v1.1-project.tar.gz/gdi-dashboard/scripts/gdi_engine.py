#!/usr/bin/env python3
"""
GDI (Gross Domestic Intelligence) Engine
=========================================
Core computation engine:
1. Historical data assembly (1991-2025)
2. Learning curve calibration (Wright's Law)
3. Monte Carlo forward simulation (2026-2046)
4. Output: JSON for dashboard consumption
"""

import json
import math
import os
import numpy as np
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional

np.random.seed(42)

# ============================================================
# SECTION 1: COUNTRY DATA & HISTORICAL RECONSTRUCTION
# ============================================================

# Countries: OECD + key emerging economies (38 total)
COUNTRIES = {
    "USA": "United States",
    "CHN": "China",
    "KOR": "South Korea",
    "GBR": "United Kingdom",
    "JPN": "Japan",
    "DEU": "Germany",
    "FRA": "France",
    "ARE": "UAE",
    "IND": "India",
    "TWN": "Taiwan",
    "CAN": "Canada",
    "AUS": "Australia",
    "NLD": "Netherlands",
    "SWE": "Sweden",
    "FIN": "Finland",
    "NOR": "Norway",
    "DNK": "Denmark",
    "BEL": "Belgium",
    "AUT": "Austria",
    "CHE": "Switzerland",
    "ESP": "Spain",
    "PRT": "Portugal",
    "IRL": "Ireland",
    "ISR": "Israel",
    "POL": "Poland",
    "CZE": "Czech Republic",
    "TUR": "Turkey",
    "MEX": "Mexico",
    "CHL": "Chile",
    "COL": "Colombia",
    "NZL": "New Zealand",
    "ITA": "Italy",
    "SGP": "Singapore",
    "SAU": "Saudi Arabia",
    "BRA": "Brazil",
    "IDN": "Indonesia",
    "GRC": "Greece",
    "HUN": "Hungary",
}

# --- Historical GDP data (selected years, billions USD current) ---
# Source: IMF WEO / World Bank (representative values)
GDP_HIST = {
    "USA": {1991: 6158, 1995: 7664, 2000: 10285, 2005: 13037, 2010: 14992, 2015: 18238, 2020: 21061, 2023: 27361, 2025: 29900},
    "CHN": {1991: 383, 1995: 735, 2000: 1211, 2005: 2286, 2010: 6087, 2015: 11062, 2020: 14688, 2023: 17795, 2025: 19500},
    "JPN": {1991: 3584, 1995: 5449, 2000: 4888, 2005: 4755, 2010: 5759, 2015: 4395, 2020: 5040, 2023: 4213, 2025: 4400},
    "DEU": {1991: 1869, 1995: 2592, 2000: 1950, 2005: 2862, 2010: 3423, 2015: 3375, 2020: 3889, 2023: 4457, 2025: 4600},
    "GBR": {1991: 1143, 1995: 1335, 2000: 1658, 2005: 2538, 2010: 2475, 2015: 2928, 2020: 2707, 2023: 3340, 2025: 3500},
    "FRA": {1991: 1276, 1995: 1601, 2000: 1362, 2005: 2197, 2010: 2647, 2015: 2438, 2020: 2639, 2023: 3031, 2025: 3150},
    "KOR": {1991: 330, 1995: 531, 2000: 562, 2005: 899, 2010: 1094, 2015: 1383, 2020: 1638, 2023: 1713, 2025: 1850},
    "IND": {1991: 274, 1995: 366, 2000: 476, 2005: 834, 2010: 1676, 2015: 2104, 2020: 2671, 2023: 3550, 2025: 4000},
    "CAN": {1991: 599, 1995: 604, 2000: 742, 2005: 1169, 2010: 1614, 2015: 1556, 2020: 1645, 2023: 2140, 2025: 2250},
    "AUS": {1991: 323, 1995: 367, 2000: 400, 2005: 695, 2010: 1147, 2015: 1232, 2020: 1331, 2023: 1688, 2025: 1800},
    "ITA": {1991: 1204, 1995: 1132, 2000: 1146, 2005: 1853, 2010: 2136, 2015: 1836, 2020: 1897, 2023: 2255, 2025: 2350},
    "BRA": {1991: 408, 1995: 786, 2000: 655, 2005: 892, 2010: 2209, 2015: 1802, 2020: 1445, 2023: 2174, 2025: 2300},
    "TWN": {1991: 187, 1995: 273, 2000: 331, 2005: 365, 2010: 446, 2015: 534, 2020: 669, 2023: 751, 2025: 820},
    "ARE": {1991: 34, 1995: 43, 2000: 70, 2005: 133, 2010: 231, 2015: 358, 2020: 350, 2023: 504, 2025: 550},
    "SAU": {1991: 118, 1995: 127, 2000: 189, 2005: 328, 2010: 527, 2015: 654, 2020: 700, 2023: 1062, 2025: 1100},
    "SGP": {1991: 47, 1995: 87, 2000: 96, 2005: 127, 2010: 236, 2015: 308, 2020: 340, 2023: 497, 2025: 530},
    "ISR": {1991: 66, 1995: 96, 2000: 134, 2005: 134, 2010: 234, 2015: 300, 2020: 402, 2023: 521, 2025: 560},
    "NLD": {1991: 322, 1995: 433, 2000: 413, 2005: 678, 2010: 837, 2015: 758, 2020: 913, 2023: 1092, 2025: 1150},
    "SWE": {1991: 267, 1995: 263, 2000: 259, 2005: 392, 2010: 488, 2015: 502, 2020: 542, 2023: 599, 2025: 630},
    "CHE": {1991: 260, 1995: 335, 2000: 272, 2005: 405, 2010: 581, 2015: 680, 2020: 752, 2023: 906, 2025: 950},
    "ESP": {1991: 546, 1995: 603, 2000: 595, 2005: 1157, 2010: 1422, 2015: 1198, 2020: 1281, 2023: 1580, 2025: 1650},
    "POL": {1991: 85, 1995: 139, 2000: 172, 2005: 304, 2010: 479, 2015: 477, 2020: 596, 2023: 811, 2025: 870},
    "NOR": {1991: 120, 1995: 149, 2000: 171, 2005: 305, 2010: 428, 2015: 387, 2020: 362, 2023: 486, 2025: 510},
    "FIN": {1991: 140, 1995: 131, 2000: 122, 2005: 196, 2010: 247, 2015: 234, 2020: 271, 2023: 301, 2025: 315},
    "DNK": {1991: 139, 1995: 185, 2000: 164, 2005: 265, 2010: 322, 2015: 303, 2020: 356, 2023: 406, 2025: 425},
    "IRL": {1991: 48, 1995: 68, 2000: 99, 2005: 210, 2010: 218, 2015: 291, 2020: 425, 2023: 545, 2025: 580},
    "TUR": {1991: 152, 1995: 169, 2000: 273, 2005: 501, 2010: 772, 2015: 864, 2020: 720, 2023: 1108, 2025: 1200},
    "MEX": {1991: 315, 1995: 343, 2000: 684, 2005: 866, 2010: 1051, 2015: 1171, 2020: 1091, 2023: 1789, 2025: 1900},
    "IDN": {1991: 128, 1995: 202, 2000: 165, 2005: 286, 2010: 755, 2015: 861, 2020: 1059, 2023: 1417, 2025: 1550},
    "CHL": {1991: 36, 1995: 72, 2000: 79, 2005: 124, 2010: 218, 2015: 243, 2020: 253, 2023: 335, 2025: 360},
    "COL": {1991: 43, 1995: 93, 2000: 100, 2005: 146, 2010: 287, 2015: 293, 2020: 271, 2023: 363, 2025: 400},
    "NZL": {1991: 42, 1995: 60, 2000: 52, 2005: 112, 2010: 146, 2015: 175, 2020: 211, 2023: 252, 2025: 265},
    "CZE": {1991: 32, 1995: 57, 2000: 61, 2005: 135, 2010: 207, 2015: 186, 2020: 245, 2023: 330, 2025: 355},
    "BEL": {1991: 219, 1995: 287, 2000: 237, 2005: 387, 2010: 484, 2015: 461, 2020: 525, 2023: 624, 2025: 660},
    "AUT": {1991: 177, 1995: 237, 2000: 196, 2005: 315, 2010: 390, 2015: 382, 2020: 436, 2023: 516, 2025: 545},
    "PRT": {1991: 87, 1995: 116, 2000: 118, 2005: 193, 2010: 238, 2015: 199, 2020: 228, 2023: 287, 2025: 305},
    "GRC": {1991: 100, 1995: 123, 2000: 130, 2005: 247, 2010: 300, 2015: 196, 2020: 189, 2023: 238, 2025: 255},
    "HUN": {1991: 34, 1995: 46, 2000: 47, 2005: 112, 2010: 130, 2015: 124, 2020: 155, 2023: 212, 2025: 225},
}

def interpolate_gdp(country: str, year: int) -> float:
    """Interpolate GDP for any year between known data points."""
    data = GDP_HIST.get(country, GDP_HIST["USA"])
    years = sorted(data.keys())
    if year <= years[0]:
        return data[years[0]]
    if year >= years[-1]:
        return data[years[-1]]
    for i in range(len(years) - 1):
        if years[i] <= year <= years[i + 1]:
            t = (year - years[i]) / (years[i + 1] - years[i])
            return data[years[i]] * (1 - t) + data[years[i + 1]] * t
    return data[years[-1]]


# --- Country-specific parameters for 2025 baseline ---
@dataclass
class CountryProfile:
    code: str
    name: str
    # Computing sub-index components (0-100)
    c_model: float  # AI model capability
    c_infra: float  # Training/inference infrastructure
    # Energy sub-index components (0-100)
    e_gen: float    # Generation capacity score
    e_td: float     # Transmission/distribution score
    e_stor: float   # Storage score
    # Efficiency
    eta: float      # Intelligence-to-economy conversion (0-1)
    # LCOE and mix
    lcoe_weighted: float  # $/kWh weighted average
    # Growth parameters
    gdp_growth_base: float  # Baseline annual GDP growth
    compute_invest_share: float  # Share of GDP going to compute investment
    energy_invest_share: float   # Share of GDP going to energy investment
    # Energy mix shares (for learning curve application)
    solar_share: float
    wind_share: float
    nuclear_share: float
    gas_share: float
    coal_share: float
    hydro_share: float
    other_share: float
    # Population (millions, 2025)
    population: float
    # Semiconductor manufacturing score (0-100)
    semi_score: float
    # GPU access score (0-100, penalized by export controls)
    gpu_access: float


PROFILES_2025: Dict[str, CountryProfile] = {
    "USA": CountryProfile("USA", "United States", 98, 100, 82, 70, 65, 0.85, 0.055, 0.022, 0.045, 0.025,
                          solar_share=0.06, wind_share=0.12, nuclear_share=0.18, gas_share=0.42, coal_share=0.16, hydro_share=0.05, other_share=0.01,
                          population=340, semi_score=45, gpu_access=100),
    "CHN": CountryProfile("CHN", "China", 88, 72, 92, 78, 75, 0.70, 0.042, 0.045, 0.040, 0.035,
                          solar_share=0.10, wind_share=0.12, nuclear_share=0.05, gas_share=0.03, coal_share=0.58, hydro_share=0.11, other_share=0.01,
                          population=1412, semi_score=30, gpu_access=55),
    "KOR": CountryProfile("KOR", "South Korea", 55, 42, 62, 82, 55, 0.82, 0.058, 0.022, 0.028, 0.022,
                          solar_share=0.06, wind_share=0.02, nuclear_share=0.30, gas_share=0.30, coal_share=0.28, hydro_share=0.01, other_share=0.03,
                          population=52, semi_score=85, gpu_access=95),
    "GBR": CountryProfile("GBR", "United Kingdom", 62, 25, 55, 65, 48, 0.80, 0.065, 0.015, 0.022, 0.018,
                          solar_share=0.05, wind_share=0.30, nuclear_share=0.14, gas_share=0.33, coal_share=0.01, hydro_share=0.02, other_share=0.15,
                          population=68, semi_score=10, gpu_access=95),
    "JPN": CountryProfile("JPN", "Japan", 50, 28, 58, 80, 52, 0.75, 0.072, 0.010, 0.020, 0.015,
                          solar_share=0.11, wind_share=0.02, nuclear_share=0.08, gas_share=0.34, coal_share=0.30, hydro_share=0.07, other_share=0.08,
                          population=124, semi_score=55, gpu_access=95),
    "DEU": CountryProfile("DEU", "Germany", 45, 15, 65, 75, 60, 0.78, 0.068, 0.012, 0.025, 0.020,
                          solar_share=0.13, wind_share=0.28, nuclear_share=0.00, gas_share=0.14, coal_share=0.25, hydro_share=0.03, other_share=0.17,
                          population=84, semi_score=15, gpu_access=95),
    "FRA": CountryProfile("FRA", "France", 58, 22, 72, 78, 42, 0.72, 0.052, 0.013, 0.020, 0.016,
                          solar_share=0.05, wind_share=0.10, nuclear_share=0.65, gas_share=0.07, coal_share=0.01, hydro_share=0.10, other_share=0.02,
                          population=68, semi_score=12, gpu_access=95),
    "ARE": CountryProfile("ARE", "UAE", 30, 68, 70, 85, 35, 0.55, 0.038, 0.030, 0.035, 0.030,
                          solar_share=0.06, wind_share=0.00, nuclear_share=0.25, gas_share=0.65, coal_share=0.00, hydro_share=0.00, other_share=0.04,
                          population=10, semi_score=2, gpu_access=85),
    "IND": CountryProfile("IND", "India", 42, 18, 55, 45, 30, 0.50, 0.048, 0.065, 0.025, 0.022,
                          solar_share=0.10, wind_share=0.05, nuclear_share=0.03, gas_share=0.05, coal_share=0.72, hydro_share=0.04, other_share=0.01,
                          population=1450, semi_score=8, gpu_access=80),
    "TWN": CountryProfile("TWN", "Taiwan", 35, 35, 48, 75, 30, 0.65, 0.062, 0.025, 0.022, 0.020,
                          solar_share=0.05, wind_share=0.03, nuclear_share=0.08, gas_share=0.42, coal_share=0.38, hydro_share=0.02, other_share=0.02,
                          population=24, semi_score=98, gpu_access=95),
    "CAN": CountryProfile("CAN", "Canada", 40, 20, 78, 72, 40, 0.72, 0.045, 0.018, 0.020, 0.015,
                          solar_share=0.02, wind_share=0.07, nuclear_share=0.14, gas_share=0.12, coal_share=0.04, hydro_share=0.59, other_share=0.02,
                          population=40, semi_score=5, gpu_access=95),
    "AUS": CountryProfile("AUS", "Australia", 30, 12, 68, 70, 50, 0.68, 0.052, 0.020, 0.018, 0.016,
                          solar_share=0.16, wind_share=0.12, nuclear_share=0.00, gas_share=0.18, coal_share=0.47, hydro_share=0.05, other_share=0.02,
                          population=26, semi_score=2, gpu_access=95),
    "NLD": CountryProfile("NLD", "Netherlands", 38, 18, 55, 80, 45, 0.78, 0.065, 0.015, 0.022, 0.018,
                          solar_share=0.14, wind_share=0.18, nuclear_share=0.03, gas_share=0.42, coal_share=0.10, hydro_share=0.00, other_share=0.13,
                          population=18, semi_score=70, gpu_access=95),
    "SWE": CountryProfile("SWE", "Sweden", 35, 14, 82, 85, 40, 0.80, 0.038, 0.020, 0.018, 0.014,
                          solar_share=0.02, wind_share=0.20, nuclear_share=0.30, gas_share=0.01, coal_share=0.00, hydro_share=0.44, other_share=0.03,
                          population=10, semi_score=5, gpu_access=95),
    "FIN": CountryProfile("FIN", "Finland", 32, 15, 75, 82, 35, 0.78, 0.042, 0.015, 0.015, 0.012,
                          solar_share=0.01, wind_share=0.18, nuclear_share=0.35, gas_share=0.05, coal_share=0.05, hydro_share=0.20, other_share=0.16,
                          population=6, semi_score=3, gpu_access=95),
    "SGP": CountryProfile("SGP", "Singapore", 38, 30, 42, 92, 20, 0.82, 0.072, 0.025, 0.020, 0.018,
                          solar_share=0.04, wind_share=0.00, nuclear_share=0.00, gas_share=0.95, coal_share=0.00, hydro_share=0.00, other_share=0.01,
                          population=6, semi_score=40, gpu_access=95),
    "SAU": CountryProfile("SAU", "Saudi Arabia", 22, 55, 75, 78, 25, 0.42, 0.035, 0.028, 0.032, 0.028,
                          solar_share=0.02, wind_share=0.00, nuclear_share=0.00, gas_share=0.43, coal_share=0.00, hydro_share=0.00, other_share=0.55,
                          population=37, semi_score=1, gpu_access=80),
    "ISR": CountryProfile("ISR", "Israel", 60, 20, 45, 72, 30, 0.85, 0.058, 0.030, 0.025, 0.015,
                          solar_share=0.12, wind_share=0.01, nuclear_share=0.00, gas_share=0.68, coal_share=0.18, hydro_share=0.00, other_share=0.01,
                          population=10, semi_score=35, gpu_access=95),
    "BRA": CountryProfile("BRA", "Brazil", 20, 5, 78, 55, 25, 0.38, 0.040, 0.025, 0.015, 0.012,
                          solar_share=0.06, wind_share=0.13, nuclear_share=0.02, gas_share=0.08, coal_share=0.03, hydro_share=0.63, other_share=0.05,
                          population=215, semi_score=1, gpu_access=85),
    "IDN": CountryProfile("IDN", "Indonesia", 15, 3, 52, 42, 15, 0.32, 0.055, 0.050, 0.012, 0.010,
                          solar_share=0.01, wind_share=0.00, nuclear_share=0.00, gas_share=0.18, coal_share=0.62, hydro_share=0.08, other_share=0.11,
                          population=280, semi_score=1, gpu_access=80),
    # Simplified profiles for remaining countries
    "NOR": CountryProfile("NOR", "Norway", 28, 10, 88, 88, 38, 0.78, 0.032, 0.020, 0.015, 0.018,
                          solar_share=0.01, wind_share=0.10, nuclear_share=0.00, gas_share=0.02, coal_share=0.00, hydro_share=0.87, other_share=0.00,
                          population=5, semi_score=2, gpu_access=95),
    "DNK": CountryProfile("DNK", "Denmark", 30, 10, 72, 88, 42, 0.80, 0.038, 0.018, 0.018, 0.016,
                          solar_share=0.07, wind_share=0.58, nuclear_share=0.00, gas_share=0.08, coal_share=0.05, hydro_share=0.00, other_share=0.22,
                          population=6, semi_score=2, gpu_access=95),
    "IRL": CountryProfile("IRL", "Ireland", 35, 15, 52, 68, 30, 0.78, 0.062, 0.048, 0.022, 0.015,
                          solar_share=0.02, wind_share=0.38, nuclear_share=0.00, gas_share=0.48, coal_share=0.05, hydro_share=0.03, other_share=0.04,
                          population=5, semi_score=15, gpu_access=95),
    "POL": CountryProfile("POL", "Poland", 22, 5, 55, 62, 18, 0.52, 0.070, 0.035, 0.015, 0.012,
                          solar_share=0.07, wind_share=0.12, nuclear_share=0.00, gas_share=0.08, coal_share=0.65, hydro_share=0.02, other_share=0.06,
                          population=37, semi_score=3, gpu_access=95),
    "TUR": CountryProfile("TUR", "Turkey", 20, 5, 62, 58, 22, 0.45, 0.058, 0.042, 0.015, 0.015,
                          solar_share=0.08, wind_share=0.12, nuclear_share=0.00, gas_share=0.22, coal_share=0.35, hydro_share=0.20, other_share=0.03,
                          population=86, semi_score=1, gpu_access=85),
    "MEX": CountryProfile("MEX", "Mexico", 18, 4, 58, 55, 18, 0.40, 0.055, 0.022, 0.012, 0.010,
                          solar_share=0.06, wind_share=0.07, nuclear_share=0.03, gas_share=0.56, coal_share=0.05, hydro_share=0.10, other_share=0.13,
                          population=130, semi_score=2, gpu_access=85),
    "ESP": CountryProfile("ESP", "Spain", 28, 8, 68, 72, 42, 0.62, 0.048, 0.020, 0.018, 0.015,
                          solar_share=0.18, wind_share=0.24, nuclear_share=0.20, gas_share=0.14, coal_share=0.02, hydro_share=0.10, other_share=0.12,
                          population=48, semi_score=3, gpu_access=95),
    "CHE": CountryProfile("CHE", "Switzerland", 35, 12, 72, 90, 38, 0.82, 0.042, 0.018, 0.018, 0.012,
                          solar_share=0.08, wind_share=0.01, nuclear_share=0.32, gas_share=0.01, coal_share=0.00, hydro_share=0.56, other_share=0.02,
                          population=9, semi_score=8, gpu_access=95),
    "BEL": CountryProfile("BEL", "Belgium", 28, 8, 52, 78, 28, 0.72, 0.062, 0.015, 0.016, 0.014,
                          solar_share=0.08, wind_share=0.14, nuclear_share=0.40, gas_share=0.25, coal_share=0.02, hydro_share=0.00, other_share=0.11,
                          population=12, semi_score=10, gpu_access=95),
    "AUT": CountryProfile("AUT", "Austria", 25, 6, 75, 82, 42, 0.75, 0.045, 0.016, 0.015, 0.013,
                          solar_share=0.06, wind_share=0.12, nuclear_share=0.00, gas_share=0.15, coal_share=0.03, hydro_share=0.58, other_share=0.06,
                          population=9, semi_score=5, gpu_access=95),
    "PRT": CountryProfile("PRT", "Portugal", 22, 4, 68, 72, 32, 0.58, 0.048, 0.018, 0.012, 0.010,
                          solar_share=0.08, wind_share=0.28, nuclear_share=0.00, gas_share=0.25, coal_share=0.00, hydro_share=0.25, other_share=0.14,
                          population=10, semi_score=1, gpu_access=95),
    "CHL": CountryProfile("CHL", "Chile", 18, 3, 65, 62, 28, 0.48, 0.045, 0.025, 0.012, 0.010,
                          solar_share=0.20, wind_share=0.10, nuclear_share=0.00, gas_share=0.15, coal_share=0.18, hydro_share=0.28, other_share=0.09,
                          population=20, semi_score=0, gpu_access=85),
    "COL": CountryProfile("COL", "Colombia", 15, 2, 60, 52, 15, 0.35, 0.052, 0.032, 0.010, 0.008,
                          solar_share=0.02, wind_share=0.01, nuclear_share=0.00, gas_share=0.12, coal_share=0.08, hydro_share=0.70, other_share=0.07,
                          population=52, semi_score=0, gpu_access=85),
    "NZL": CountryProfile("NZL", "New Zealand", 25, 5, 82, 78, 22, 0.72, 0.042, 0.022, 0.012, 0.010,
                          solar_share=0.02, wind_share=0.07, nuclear_share=0.00, gas_share=0.11, coal_share=0.03, hydro_share=0.58, other_share=0.19,
                          population=5, semi_score=0, gpu_access=95),
    "CZE": CountryProfile("CZE", "Czech Republic", 22, 5, 58, 72, 22, 0.58, 0.062, 0.025, 0.014, 0.012,
                          solar_share=0.05, wind_share=0.02, nuclear_share=0.37, gas_share=0.08, coal_share=0.38, hydro_share=0.03, other_share=0.07,
                          population=11, semi_score=3, gpu_access=95),
    "GRC": CountryProfile("GRC", "Greece", 18, 3, 55, 60, 25, 0.48, 0.058, 0.015, 0.012, 0.010,
                          solar_share=0.15, wind_share=0.22, nuclear_share=0.00, gas_share=0.38, coal_share=0.08, hydro_share=0.08, other_share=0.09,
                          population=10, semi_score=0, gpu_access=95),
    "HUN": CountryProfile("HUN", "Hungary", 20, 4, 52, 68, 18, 0.52, 0.060, 0.028, 0.013, 0.011,
                          solar_share=0.10, wind_share=0.02, nuclear_share=0.44, gas_share=0.22, coal_share=0.06, hydro_share=0.01, other_share=0.15,
                          population=10, semi_score=2, gpu_access=95),
    "ITA": CountryProfile("ITA", "Italy", 30, 8, 62, 68, 38, 0.65, 0.058, 0.012, 0.016, 0.013,
                          solar_share=0.12, wind_share=0.08, nuclear_share=0.00, gas_share=0.47, coal_share=0.04, hydro_share=0.14, other_share=0.15,
                          population=59, semi_score=10, gpu_access=95),
}


# ============================================================
# SECTION 2: GDI COMPUTATION FUNCTIONS
# ============================================================

def compute_C(profile: CountryProfile) -> float:
    """Compute the Computing sub-index."""
    alpha1, alpha2 = 0.35, 0.65
    # Adjust c_infra by GPU access
    c_infra_eff = profile.c_infra * (profile.gpu_access / 100.0)
    return alpha1 * profile.c_model + alpha2 * c_infra_eff


def compute_E(profile: CountryProfile) -> float:
    """Compute the Effective Energy sub-index with bottleneck."""
    e_gen = profile.e_gen
    e_td = profile.e_td
    e_stor = profile.e_stor
    # Bottleneck: effective energy is constrained by weakest link
    e_bottleneck = min(e_gen, e_td, e_stor)
    # Weighted: 50% bottleneck, 50% weighted average (to avoid too extreme results)
    e_weighted = 0.4 * e_gen + 0.35 * e_td + 0.25 * e_stor
    e_raw = 0.5 * e_bottleneck + 0.5 * e_weighted
    # LCOE capital efficiency adjustment: cheaper energy = higher score
    lcoe_ref = 0.034  # best global LCOE (onshore wind)
    lcoe_efficiency = lcoe_ref / max(profile.lcoe_weighted, 0.01)
    lcoe_factor = min(lcoe_efficiency, 1.0) * 0.3 + 0.7  # 0.7-1.0 range
    return e_raw * lcoe_factor


def gdi_leontief(C: float, E: float, eta: float, gdp_factor: float) -> float:
    """GDI using Leontief (strict bottleneck)."""
    return min(C, E) * eta * gdp_factor


def gdi_ces(C: float, E: float, eta: float, gdp_factor: float,
            alpha: float = 0.55, sigma: float = 0.2) -> float:
    """GDI using CES production function."""
    if sigma <= 0.01:
        return gdi_leontief(C, E, eta, gdp_factor)
    rho = (sigma - 1) / sigma
    if abs(rho) < 1e-10:  # Cobb-Douglas
        F = (C ** alpha) * (E ** (1 - alpha))
    else:
        val = alpha * (max(C, 0.01) ** rho) + (1 - alpha) * (max(E, 0.01) ** rho)
        F = val ** (1 / rho)
    return F * eta * gdp_factor


def gdp_factor(gdp: float, gdp_max: float = 30000) -> float:
    """Economic sustainability multiplier: log-normalized GDP."""
    return math.log(max(gdp, 1)) / math.log(gdp_max)


# ============================================================
# SECTION 3: HISTORICAL RECONSTRUCTION
# ============================================================

def reconstruct_historical(profile: CountryProfile, start_year: int = 1991, end_year: int = 2025) -> List[dict]:
    """Reconstruct historical GDI trajectory for a country."""
    results = []
    code = profile.code

    for year in range(start_year, end_year + 1):
        gdp = interpolate_gdp(code, year)
        gf = gdp_factor(gdp)

        # -- Computing evolution --
        # Pre-2012: minimal AI compute; based on general HPC/semiconductor capacity
        # 2012-2017: early deep learning
        # 2018+: rapid AI infrastructure buildout
        progress = (year - start_year) / (end_year - start_year)

        if year < 2005:
            c_model_t = profile.c_model * 0.02 * (1 + (year - 1991) * 0.005)
            c_infra_t = profile.c_infra * 0.05 * (1 + (year - 1991) * 0.02)
        elif year < 2012:
            c_model_t = profile.c_model * 0.05 * (1 + (year - 2005) * 0.02)
            c_infra_t = profile.c_infra * 0.10 * (1 + (year - 2005) * 0.04)
        elif year < 2018:
            frac = (year - 2012) / 6
            c_model_t = profile.c_model * (0.10 + 0.25 * frac)
            c_infra_t = profile.c_infra * (0.15 + 0.25 * frac)
        else:
            frac = (year - 2018) / (end_year - 2018)
            # Exponential ramp from 2018 to 2025
            c_model_t = profile.c_model * (0.35 + 0.65 * (frac ** 0.7))
            c_infra_t = profile.c_infra * (0.40 + 0.60 * (frac ** 0.6))

        # -- Energy evolution --
        # Slower, steadier growth
        e_gen_t = profile.e_gen * (0.55 + 0.45 * progress)
        e_td_t = profile.e_td * (0.65 + 0.35 * progress)
        e_stor_t = profile.e_stor * (0.10 + 0.90 * max(0, (year - 2010) / (end_year - 2010)) if year >= 2010 else 0.10)

        # Eta evolution (AI adoption)
        if year < 2015:
            eta_t = profile.eta * 0.30
        elif year < 2020:
            eta_t = profile.eta * (0.30 + 0.35 * (year - 2015) / 5)
        else:
            eta_t = profile.eta * (0.65 + 0.35 * (year - 2020) / (end_year - 2020))

        # LCOE evolution (learning curves applied backwards)
        lcoe_t = profile.lcoe_weighted * (1.5 - 0.5 * progress)  # rough historical LCOE decline

        # Create temp profile for computation
        tmp = CountryProfile(
            code=code, name=profile.name,
            c_model=c_model_t, c_infra=c_infra_t,
            e_gen=e_gen_t, e_td=e_td_t, e_stor=e_stor_t,
            eta=eta_t, lcoe_weighted=lcoe_t,
            gdp_growth_base=profile.gdp_growth_base,
            compute_invest_share=profile.compute_invest_share,
            energy_invest_share=profile.energy_invest_share,
            solar_share=profile.solar_share, wind_share=profile.wind_share,
            nuclear_share=profile.nuclear_share, gas_share=profile.gas_share,
            coal_share=profile.coal_share, hydro_share=profile.hydro_share,
            other_share=profile.other_share, population=profile.population,
            semi_score=profile.semi_score, gpu_access=profile.gpu_access
        )

        C = compute_C(tmp)
        E = compute_E(tmp)
        gdi_s = gdi_leontief(C, E, eta_t, gf)
        gdi_f = gdi_ces(C, E, eta_t, gf, alpha=0.55, sigma=0.2)

        results.append({
            "year": year, "C": round(C, 2), "E": round(E, 2),
            "c_model": round(c_model_t, 2), "c_infra": round(c_infra_t, 2),
            "e_gen": round(e_gen_t, 2), "e_td": round(e_td_t, 2), "e_stor": round(e_stor_t, 2),
            "eta": round(eta_t, 3), "gdp": round(gdp, 1),
            "gdi_strict": round(gdi_s, 2), "gdi_flex": round(gdi_f, 2),
        })

    return results


# ============================================================
# SECTION 4: MONTE CARLO FORWARD SIMULATION
# ============================================================

# Wright's Law learning rates
LEARNING_RATES = {
    "solar": {"mean": 0.22, "std": 0.03},
    "wind": {"mean": 0.16, "std": 0.03},
    "battery": {"mean": 0.20, "std": 0.04},
    "ai_chip": {"mean": 0.375, "std": 0.05},
    "nuclear": {"mean": 0.0, "std": 0.02},
    "gas": {"mean": 0.05, "std": 0.02},
}

# Cumulative production doubling times (years)
DOUBLING_TIMES = {
    "solar": {"mean": 2.5, "std": 0.5},
    "wind": {"mean": 3.5, "std": 0.7},
    "battery": {"mean": 2.0, "std": 0.4},
    "ai_chip": {"mean": 0.85, "std": 0.2},  # ~10 months
}


def wright_cost(initial_cost: float, cumulative_doublings: float, learning_rate: float) -> float:
    """Apply Wright's Law: cost after n doublings."""
    return initial_cost * ((1 - learning_rate) ** cumulative_doublings)


def run_monte_carlo(profile: CountryProfile, n_runs: int = 2000,
                    start_year: int = 2026, end_year: int = 2046) -> dict:
    """Run Monte Carlo simulation for a single country."""
    n_years = end_year - start_year + 1
    code = profile.code

    # Get 2025 baseline values
    C_2025 = compute_C(profile)
    E_2025 = compute_E(profile)
    gdp_2025 = interpolate_gdp(code, 2025)
    eta_2025 = profile.eta

    # Storage arrays: [n_runs, n_years]
    gdi_strict_all = np.zeros((n_runs, n_years))
    gdi_flex_all = np.zeros((n_runs, n_years))
    C_all = np.zeros((n_runs, n_years))
    E_all = np.zeros((n_runs, n_years))

    for run in range(n_runs):
        # Sample parameters for this run
        lr_solar = np.clip(np.random.normal(LEARNING_RATES["solar"]["mean"], LEARNING_RATES["solar"]["std"]), 0.05, 0.40)
        lr_wind = np.clip(np.random.normal(LEARNING_RATES["wind"]["mean"], LEARNING_RATES["wind"]["std"]), 0.05, 0.30)
        lr_battery = np.clip(np.random.normal(LEARNING_RATES["battery"]["mean"], LEARNING_RATES["battery"]["std"]), 0.05, 0.35)
        lr_ai = np.clip(np.random.normal(LEARNING_RATES["ai_chip"]["mean"], LEARNING_RATES["ai_chip"]["std"]), 0.15, 0.55)

        dt_solar = max(1.0, np.random.normal(DOUBLING_TIMES["solar"]["mean"], DOUBLING_TIMES["solar"]["std"]))
        dt_wind = max(1.5, np.random.normal(DOUBLING_TIMES["wind"]["mean"], DOUBLING_TIMES["wind"]["std"]))
        dt_ai = max(0.4, np.random.normal(DOUBLING_TIMES["ai_chip"]["mean"], DOUBLING_TIMES["ai_chip"]["std"]))

        # GDP growth rate for this run
        gdp_g = np.clip(np.random.normal(profile.gdp_growth_base, 0.01), -0.02, 0.10)

        # AI-to-GDP multiplier
        alpha_ai = np.clip(np.random.normal(0.03, 0.015), 0.005, 0.08)

        # Algorithmic efficiency improvement (annual multiplier)
        algo_improve = np.clip(np.random.normal(0.25, 0.08), 0.05, 0.50)

        # State initialization
        C_t = C_2025
        E_t = E_2025
        gdp_t = gdp_2025
        eta_t = eta_2025
        lcoe_t = profile.lcoe_weighted

        for y_idx in range(n_years):
            year = start_year + y_idx
            t = y_idx + 1  # years from 2025

            # --- Computing evolution ---
            # Hardware learning: cumulative doublings of AI chip production
            cum_doublings_ai = t / dt_ai
            hw_cost_factor = (1 - lr_ai) ** cum_doublings_ai
            # Investment in compute
            invest_c = gdp_t * profile.compute_invest_share
            # New compute = investment / declining unit cost
            delta_c_invest = invest_c / max(hw_cost_factor * 10, 0.1) * 0.001  # scaling factor
            # Algorithmic improvement
            delta_c_algo = C_t * algo_improve * 0.1
            # Depreciation (25% base)
            depreciation = C_t * np.clip(np.random.normal(0.25, 0.03), 0.15, 0.35)

            C_t = max(1, C_t + delta_c_invest + delta_c_algo - depreciation)
            # Cap at reasonable maximum with growth
            C_t = min(C_t, 200)

            # --- Energy evolution ---
            # LCOE learning curves
            cum_d_solar = t / dt_solar
            cum_d_wind = t / dt_wind
            lcoe_solar = 0.043 * ((1 - lr_solar) ** cum_d_solar)
            lcoe_wind = 0.034 * ((1 - lr_wind) ** cum_d_wind)
            lcoe_gas = 0.065  # relatively stable
            lcoe_nuclear = 0.080  # relatively stable
            lcoe_coal = 0.075

            new_lcoe = (
                profile.solar_share * lcoe_solar +
                profile.wind_share * lcoe_wind +
                profile.nuclear_share * lcoe_nuclear +
                profile.gas_share * lcoe_gas +
                profile.coal_share * lcoe_coal +
                profile.hydro_share * 0.057 +
                profile.other_share * 0.060
            )
            lcoe_t = new_lcoe

            # Energy investment buys more at lower LCOE
            invest_e = gdp_t * profile.energy_invest_share
            lcoe_ref = 0.034
            lcoe_efficiency = lcoe_ref / max(lcoe_t, 0.01)
            delta_e_invest = invest_e * lcoe_efficiency * 0.0008  # scaling

            # Retirement of old generation
            retirement = E_t * np.clip(np.random.normal(0.02, 0.005), 0.005, 0.04)

            # Grid bottleneck improvement (slow)
            grid_improve = 0.005 * t  # very gradual

            E_t = max(1, E_t + delta_e_invest - retirement + grid_improve)
            E_t = min(E_t, 200)

            # --- Eta evolution ---
            eta_t = min(0.98, eta_2025 + 0.008 * t * (1 + alpha_ai))

            # --- GDP evolution with feedback ---
            gdi_current = gdi_ces(C_t, E_t, eta_t, gdp_factor(gdp_t))
            gdp_boost = alpha_ai * gdi_current / 100 * 0.01
            gdp_t = gdp_t * (1 + gdp_g + gdp_boost)

            gf = gdp_factor(gdp_t)
            gdi_s = gdi_leontief(C_t, E_t, eta_t, gf)
            gdi_f = gdi_ces(C_t, E_t, eta_t, gf, alpha=0.55, sigma=0.2)

            gdi_strict_all[run, y_idx] = gdi_s
            gdi_flex_all[run, y_idx] = gdi_f
            C_all[run, y_idx] = C_t
            E_all[run, y_idx] = E_t

    # Compute percentiles
    percentiles = [2.5, 10, 25, 50, 75, 90, 97.5]
    forecast = []
    for y_idx in range(n_years):
        year = start_year + y_idx
        entry = {"year": year}
        for pct in percentiles:
            p_str = f"p{pct:.1f}".replace(".", "_")
            entry[f"gdi_strict_{p_str}"] = round(float(np.percentile(gdi_strict_all[:, y_idx], pct)), 2)
            entry[f"gdi_flex_{p_str}"] = round(float(np.percentile(gdi_flex_all[:, y_idx], pct)), 2)
            entry[f"C_{p_str}"] = round(float(np.percentile(C_all[:, y_idx], pct)), 2)
            entry[f"E_{p_str}"] = round(float(np.percentile(E_all[:, y_idx], pct)), 2)
        forecast.append(entry)

    return forecast


# ============================================================
# SECTION 5: MAIN EXECUTION
# ============================================================

def main():
    print("=" * 60)
    print("GDI Engine: Computing Historical + Forecast Data")
    print("=" * 60)

    output = {
        "metadata": {
            "version": "1.0",
            "generated": "2026-02",
            "countries": len(PROFILES_2025),
            "historical_range": "1991-2025",
            "forecast_range": "2026-2046",
            "monte_carlo_runs": 2000,
        },
        "countries": {},
        "learning_curves": {
            "solar_pv": {"learning_rate": 0.22, "initial_lcoe": 0.043, "unit": "$/kWh"},
            "onshore_wind": {"learning_rate": 0.16, "initial_lcoe": 0.034, "unit": "$/kWh"},
            "battery": {"learning_rate": 0.20, "initial_cost": 139, "unit": "$/kWh"},
            "ai_chip": {"learning_rate": 0.375, "cost_decline_per_year": 0.48, "unit": "RCU cost"},
        },
    }

    for code, profile in PROFILES_2025.items():
        print(f"  Processing {code} ({profile.name})...")

        # 2025 snapshot
        C = compute_C(profile)
        E = compute_E(profile)
        gdp = interpolate_gdp(code, 2025)
        gf = gdp_factor(gdp)
        gdi_s = gdi_leontief(C, E, profile.eta, gf)
        gdi_f = gdi_ces(C, E, profile.eta, gf)

        # Historical reconstruction
        historical = reconstruct_historical(profile, 1991, 2025)

        # Monte Carlo forecast
        forecast = run_monte_carlo(profile, n_runs=2000, start_year=2026, end_year=2046)

        output["countries"][code] = {
            "name": profile.name,
            "population": profile.population,
            "snapshot_2025": {
                "C": round(C, 2),
                "E": round(E, 2),
                "c_model": profile.c_model,
                "c_infra": profile.c_infra,
                "e_gen": profile.e_gen,
                "e_td": profile.e_td,
                "e_stor": profile.e_stor,
                "eta": profile.eta,
                "gdp": round(gdp, 1),
                "lcoe_weighted": profile.lcoe_weighted,
                "gdi_strict": round(gdi_s, 2),
                "gdi_flex": round(gdi_f, 2),
                "gdi_strict_per_capita": round(gdi_s / profile.population * 1000, 3),
                "gdi_flex_per_capita": round(gdi_f / profile.population * 1000, 3),
                "semi_score": profile.semi_score,
                "gpu_access": profile.gpu_access,
                "energy_mix": {
                    "solar": profile.solar_share,
                    "wind": profile.wind_share,
                    "nuclear": profile.nuclear_share,
                    "gas": profile.gas_share,
                    "coal": profile.coal_share,
                    "hydro": profile.hydro_share,
                    "other": profile.other_share,
                },
            },
            "historical": historical,
            "forecast": forecast,
        }

    # Write output
    out_path = os.path.join(os.path.dirname(__file__), "..", "src", "data", "gdi_data.json")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path, "w") as f:
        json.dump(output, f, indent=None, separators=(",", ":"))

    print(f"\nData written to {out_path}")
    print(f"File size: {os.path.getsize(out_path) / 1024 / 1024:.1f} MB")

    # Also write a lightweight summary for quick loading
    summary = {
        "metadata": output["metadata"],
        "rankings_2025": sorted([
            {
                "code": code,
                "name": data["name"],
                "gdi_strict": data["snapshot_2025"]["gdi_strict"],
                "gdi_flex": data["snapshot_2025"]["gdi_flex"],
                "C": data["snapshot_2025"]["C"],
                "E": data["snapshot_2025"]["E"],
                "eta": data["snapshot_2025"]["eta"],
                "gdp": data["snapshot_2025"]["gdp"],
                "population": data["population"],
            }
            for code, data in output["countries"].items()
        ], key=lambda x: -x["gdi_flex"]),
    }
    summary_path = os.path.join(os.path.dirname(out_path), "gdi_summary.json")
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    print(f"Summary written to {summary_path}")
    print("Done!")


if __name__ == "__main__":
    main()
