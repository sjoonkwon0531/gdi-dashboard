# GDI — Gross Domestic Intelligence

**Measuring National AI Capability through Computing Power and Energy Infrastructure**

A framework for quantifying and forecasting national AI capability as a function of computing infrastructure, energy supply, and economic feedback loops.

## Model Overview

```
GDI = F(C, E) × η × Φ(GDP)
```

Where:
- **C** = Computing Power (AI models + infrastructure)
- **E** = Effective Energy (generation × T&D × storage × capital efficiency)
- **η** = Intelligence-to-economy conversion efficiency
- **Φ(GDP)** = Economic sustainability multiplier

Two production functions run in parallel:
- **Leontief** (strict bottleneck): `GDI_strict = min(C, E) × η × Φ`
- **CES** (adjustable): `GDI_flex = [αC^ρ + (1-α)E^ρ]^(1/ρ) × η × Φ`

## Key Features

- **38 countries** tracked (OECD + key emerging economies)
- **Historical reconstruction** from 1991–2025
- **Monte Carlo forecasting** to 2046 with 95% confidence intervals
- **Wright's Law** learning curves for AI chips (37.5%), solar (22%), wind (16%), batteries (20%)
- **Interactive dashboard** with rankings, trajectories, C-vs-E phase space, and country deep dives

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Data Engine | Python 3 (NumPy) |
| Frontend | React + Recharts |
| Framework | Next.js 14 |
| Deployment | Vercel |

## Quick Start

```bash
# Generate data
python3 scripts/gdi_engine.py

# Install dependencies
npm install

# Run development server
npm run dev
```

## Data Sources

- **Computing**: Epoch AI, Chatbot Arena, SEMI World Fab Forecast, TRG Datacenters
- **Energy**: IEA World Energy Outlook, IRENA LCOE 2024, Fraunhofer ISE
- **Economic**: IMF WEO, World Bank, Microsoft AI Economy Institute
- **Benchmarks**: Stanford HAI AI Index, Tortoise Global AI Index

## Project Structure

```
gdi-dashboard/
├── scripts/
│   └── gdi_engine.py          # Data pipeline + Monte Carlo engine
├── src/
│   ├── data/
│   │   ├── gdi_data.json      # Full dataset (38 countries)
│   │   └── gdi_summary.json   # Rankings summary
│   └── components/
│       └── GDIDashboard.jsx   # Interactive dashboard
├── public/
├── package.json
└── README.md
```

## Documents

- `GDI_Model_Design_Document_v1.0.docx` — Complete model specification
- `GDI_Supplement_A_Temporal_Dynamics.docx` — Time dynamics, learning curves, forecasting

## License

Research use. Not for redistribution without permission.
